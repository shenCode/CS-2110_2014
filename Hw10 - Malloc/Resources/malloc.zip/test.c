#include <stdlib.h>
#include "my_malloc.h"
#include "list.h"

int main() {
	
	/*
	 * Test code goes here
	 */
	 
	return 0;
}
