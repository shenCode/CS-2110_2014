#include <stdlib.h>
#include "mylib.h"
#include "mystery.h"
#include "mystery2.h"
#include "mystery3.h"

extern const u16 mystery[38400];
extern const u16 mystery2[38400];
extern const u16 mystery3[38400];

int main(void)
{
    REG_DISPCNT = MODE3 | BG2_ENABLE;

    while (1)
    {
        waitForVblank();
        /* Draw the mystery image (flipped horizontally & vertially) stored in the array mystery defined in mystery.c onto the screen here*/
        /* Now consider this what if the image was just flipped horizontally how could you draw it correctly with DMA? (mystery2) */
        /* Then consider if the image was just flipped vertically how could you draw it correctly with DMA? (mystery3) */
    }
}
