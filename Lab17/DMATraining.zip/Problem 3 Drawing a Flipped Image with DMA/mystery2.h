/*
 * Exported with BrandonTools v0.9
 * Invocation command was BrandonTools -mode3 mystery2 mystery2.png 
 * 
 * Image Information
 * -----------------
 * mystery2.png 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * All generalizations are bad.  ~R.H. Grenier
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef MYSTERY2_BITMAP_H
#define MYSTERY2_BITMAP_H

extern const unsigned short mystery2[38400];
#define MYSTERY2_WIDTH 240
#define MYSTERY2_HEIGHT 160

#endif
