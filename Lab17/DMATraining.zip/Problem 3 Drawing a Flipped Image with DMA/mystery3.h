/*
 * Exported with BrandonTools v0.9
 * Invocation command was BrandonTools -mode3 mystery3 mystery3.png 
 * 
 * Image Information
 * -----------------
 * mystery3.png 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * All generalizations are bad.  ~R.H. Grenier
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef MYSTERY3_BITMAP_H
#define MYSTERY3_BITMAP_H

extern const unsigned short mystery3[38400];
#define MYSTERY3_WIDTH 240
#define MYSTERY3_HEIGHT 160

#endif
