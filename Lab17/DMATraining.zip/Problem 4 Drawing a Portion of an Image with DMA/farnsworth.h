#ifndef FARNSWORTH_BITMAP_H
#define FARNSWORTH_BITMAP_H

extern const unsigned short farnsworth[38400];
#define FARNSWORTH_WIDTH 240
#define FARNSWORTH_HEIGHT 160

#endif