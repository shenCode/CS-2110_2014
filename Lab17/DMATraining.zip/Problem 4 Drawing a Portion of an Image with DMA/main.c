#include <stdlib.h>
#include "mylib.h"
#include "farnsworth.h"
#include "spritesheet.h"

extern const u16 farnsworth[38400];

void drawFarnsworthHead(int x, int y, int width, int height, const u16* farnsworth);
void blit(int dx, int dy, int sx, int sy, int swidth, int sheight, const u16* image, int iwidth);

int main(void)
{
    REG_DISPCNT = MODE3 | BG2_ENABLE;

    while (1)
    {
        waitForVblank();
        /* Draw farnsworths head*/
        /* Parameters passed in are the bounding box of his head */
        /* You are free to draw it anywhere you want */
        /* Image is contained in farnsworth defined in farnsworth.c */
        drawFarnsworthHead(29,33,60,62, farnsworth);
    }
}

/* x y width height are the dimensions of farnsworth's head */
/* I didn't care where you draw it but it should appear on the screen after this is called */
void drawFarnsworthHead(int x, int y, int width, int height, const u16* farnsworth)
{
}


/* 
 Now if you can handle drawFarnsworthHead then try this one out 
 What the function drawFarnsworthHead is an example of the function below
 It is called a bitblock-transfer or blit you don't need to learn these terms for this class
 but if you want to learn more here is the wikipedia article http://en.wikipedia.org/wiki/Bit_blit
 
 So you will write this function called blit it takes eight parameters
 the destination x (dx) and destination y (dy) which tells where the image will go.
 
 and the next four parameters (sx, sy, swidth, sheight) give the dimensions and location of the bounding box of the image

 the next parameter is a pointer to the image data and lastly the width of the image.
 
 So in summary this function is like drawFarnsworthHead except I want to put a portion of an arbitrary sized image on the screen at (dx, dy)
*/

/* To test this I have included a spritesheet each graphic in this image is 60x60 and there are 8 of these graphics in a row.  You can make it appear animated by drawing the graphics of the spritesheet once per frame moving to the next one after each frame. */
void blit(int dx, int dy, int sx, int sy, int swidth, int sheight, const u16* image, int iwidth)
{
}
