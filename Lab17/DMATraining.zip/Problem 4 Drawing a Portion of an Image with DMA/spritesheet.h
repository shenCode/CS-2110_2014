/*
 * Exported with BrandonTools v0.9
 * Invocation command was BrandonTools -mode3 spritesheet spritesheet.png 
 * Time-stamp: Wednesday 03/28/2012, 15:40:17
 * 
 * Image Information
 * -----------------
 * spritesheet.png 480@480
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * A celebrity is a person who works hard all his life to become well known,
 *  then wears dark glasses to avoid being recognized.  ~Fred Allen
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef SPRITESHEET_BITMAP_H
#define SPRITESHEET_BITMAP_H

extern const unsigned short spritesheet[230400];
#define SPRITESHEET_WIDTH 480
#define SPRITESHEET_HEIGHT 480

#endif