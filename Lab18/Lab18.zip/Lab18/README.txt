Greetings, student!

In today's lab, you will be making an integer linked list in C. It must conform to the following requirements:

1. The list must be singly linked, i.e. each only node points to the next node in the list.
2. The list must have head and tail pointers
3. The tail of the list must have its next pointer point to NULL
4. The list must only hold integer values as data, so no need for using a pointer for that.
5. The code must implement add, remove, and get operations, in addition to a function for printing a node in a nicely-formatted way.
6. The nodes in the list must remain SORTED at all times. This means when you insert a number, you have to find the correct place in the list to put that number.

Note that in this lab you will NOT be using any function pointers. You don't need to worry about that.
Your add/remove operations will operate on the nodes of the list directly.
Also, you will need to use malloc/free for the nodes, but remember, the data is just ints.

Make sure that you test your list thoroughly in your main.c file.

We've given you some base code to work off of. All you have to do is implement each function as specified.

Have fun!
