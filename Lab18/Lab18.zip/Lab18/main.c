#include "list.h"
#include <stdio.h>

// CS2110 Spring 2014
// Your name here

// Test your list code here! Make sure you test all the cases!
int main()
{
	LIST* llist = create_list();

	list_add(llist, 1);

	// Your tests here
	return 0;
}
