#include "mylib.h"
#include "rle.h"

void drawUncompressedImage(const u16* data);

int main(void)
{
    REG_DISPCNT = 1027;
  
    // Call this function with rle2 and rle1 these are HARDER test cases for you to ensure it works.  
    drawUncompressedImage(rle3);
    
    while(1);
}

/*
    Draws an RLE encoded image uncompressed onto the videoBuffer.
		Keep in mind that the format is: {run, data, run, data, ... }
*/
void drawUncompressedImage(const u16* data)
{

}
